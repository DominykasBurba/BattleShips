global using BattleShips.Domain;
global using BattleShips.Domain.Ships;
global using BattleShips.Services;